// Исходный массив с товарами
const products = [
  "Мышка",
  "Клавиатура",
  "Наушники",
  "Монитор",
  "Принтер",
  "Флешка",
];

// Находим элемент <ul> в DOM
const productsList = document.querySelector(".products");

// Генерируем список товаров
products.forEach((product) => {
  const listItem = document.createElement("li");
  listItem.textContent = product;
  productsList.appendChild(listItem);
});
