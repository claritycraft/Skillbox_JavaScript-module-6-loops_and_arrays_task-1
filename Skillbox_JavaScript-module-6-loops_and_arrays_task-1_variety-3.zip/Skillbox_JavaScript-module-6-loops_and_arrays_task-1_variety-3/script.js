const products = [
  "Мышка",
  "Клавиатура",
  "Наушники",
  "Монитор",
  "Принтер",
  "Флешка",
];

const productsList = document.querySelector(".products");

for (let i = 0; i < products.length; i++) {
  const listItem = document.createElement("li");

  listItem.textContent = products[i];
  productsList.appendChild(listItem);
}
